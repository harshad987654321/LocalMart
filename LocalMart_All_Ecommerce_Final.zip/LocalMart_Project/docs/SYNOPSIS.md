# SYNOPSIS – LocalMart

## Project Title
LocalMart – Online Shopping Platform for Local Businesses

## Introduction
LocalMart is a web-based local-business e-commerce system that lets local sellers display products online and lets customers browse products, use a shopping cart, place orders and track order status.

## Objectives
1. Digitize product display for local businesses.
2. Provide customers with a simple online shopping interface.
3. Store customer, product and order data in MySQL.
4. Provide an admin panel for products, stock, customers and orders.
5. Generate basic sales information.

## Modules
Customer registration/login, product search and categories, product details, cart, checkout/address, order history/tracking, admin product/category/stock management, customer/order management and basic sales reports.

## Technologies
Frontend: HTML5, CSS3, JavaScript, Bootstrap
Backend: Python Flask
Database: MySQL

## Scope
The academic version focuses on core shopping and administration. Online payment gateway and delivery management are outside the basic version.
