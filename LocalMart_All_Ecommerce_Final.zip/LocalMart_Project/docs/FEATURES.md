# LocalMart — Complete E-Commerce Feature List

## Customer storefront
- Professional responsive homepage
- Hero banner and promotional sections
- Category navigation
- Product catalogue
- Product search
- Product sorting
- Product detail pages
- Product images
- Product pricing and sale pricing
- Stock indicators
- Related products
- Flash/deal presentation
- Add to cart
- Cart quantity updates
- Coupon application
- Wishlist
- Product ratings and reviews

## Customer account
- Registration
- Login/logout
- Account/profile
- Profile update
- Order history
- Order detail/tracking view
- Wishlist management
- Saved customer information

## Checkout
- Shipping address
- Order summary
- Discount calculation
- Coupon support
- Shipping calculation
- Payment method selection
- Order confirmation

## Admin
- Admin dashboard
- Sales overview
- Product management
- Product deletion
- Order management
- Order status updates
- Customer management
- Reports
- Category/product data management

## Database
- users
- categories
- products
- orders
- order_items
- wishlists
- reviews
- coupons

## Technical
- Flask backend
- MySQL database
- HTML/CSS/JavaScript frontend
- Responsive mobile/tablet/desktop layout
- `.env.example` configuration
- Health endpoint
- Project documentation
